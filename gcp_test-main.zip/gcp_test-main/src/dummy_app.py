import numpy as np  
import pandas as pd 

def square(x):
    return x * x

